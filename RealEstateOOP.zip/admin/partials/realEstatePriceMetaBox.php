<div class="metaBox">
 
    <table id="realEstatePriceMetaBoxData">
        <tr>
            <td><input type="text" size="80" name="realEstatePrice" value="<?php echo $price; ?>" /><sup>PLN</sup></td>
        </tr>
    </table>
 
</div>