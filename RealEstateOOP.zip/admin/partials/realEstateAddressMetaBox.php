<div class="metaBox">
 
    <table id="realEstateAddressMetaBoxData">
        <tr>
            <td><input type="text" size="80" name="realEstateAddress" value="<?php echo $address; ?>" /></td>
        </tr>
    </table>
 
</div>