<div class="metaBox">
 
    <table id="realEstateAreaMetaBoxData">
        <tr>
            <td><input type="text" size="80" name="realEstateArea" value="<?php echo $area; ?>" />m<sup>2</sup></td>
        </tr>
    </table>
 
</div>